<!DOCTYPE html>
<html lang="<?php echo USER_LANG; ?>">
	<head>
		<meta charset="UTF-8" />
		<meta name="robots" content="noindex, nofollow" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title><?php if (isset($GLOBALS['page_title'])): echo $GLOBALS['page_title'].' | '; endif; echo AdminServUI::getTitle(); ?></title>
		<link type="image/png" rel="icon" href="<?php echo AdminServConfig::$PATH_RESOURCES; ?>images/32/favicon.png" sizes="32x32" />
		<?php echo AdminServUI::getCss(); ?>
		<?php echo AdminServUI::getJS(); ?>
	</head>
	<body<?php if( isset($GLOBALS['body_class']) && $GLOBALS['body_class'] ){ echo ' class="'.$GLOBALS['body_class'].'"'; } ?>>
		<div id="page">
			<div id="page-inner">

				<!-- ===== HEADER ===== -->
				<header>
					<div id="header-inner">

						<!-- Logo + title -->
						<div class="logo-title">
							<a href="./">
								<?php if (AdminServConfig::LOGO): ?>
									<span id="logo">
										<img src="<?php echo AdminServConfig::$PATH_RESOURCES.'images/'.AdminServConfig::LOGO; ?>" alt="" />
									</span>
								<?php endif; ?>
								<span class="title-subtitle">
									<span id="title">#<?php echo AdminServUI::getTitle('html'); ?></span>
									<?php if (AdminServConfig::SUBTITLE): ?>
										<span id="subtitle"><?php echo AdminServConfig::SUBTITLE; ?></span>
									<?php endif; ?>
								</span>
							</a>
						</div>

						<!-- Settings button + theme/language popover -->
						<?php if (!empty(ExtensionConfig::$THEMES) || !empty(ExtensionConfig::$LANG)): ?>
							<button
								id="settings-btn"
								class="settings-btn"
								aria-haspopup="true"
								aria-expanded="false"
								aria-label="<?php echo Utils::t('Settings'); ?>"
								title="<?php echo Utils::t('Theme and language'); ?>">
								&#9881;
							</button>

							<div id="settings-popover" class="settings-popover" role="dialog" aria-label="<?php echo Utils::t('Settings'); ?>">

								<?php if (!empty(ExtensionConfig::$THEMES)): ?>
									<div class="settings-section">
										<div class="settings-section-title"><?php echo Utils::t('Theme'); ?></div>
										<?php echo AdminServUI::getThemeList(); ?>
									</div>
								<?php endif; ?>

								<?php if (!empty(ExtensionConfig::$LANG)): ?>
									<div class="settings-section">
										<div class="settings-section-title"><?php echo Utils::t('Language'); ?></div>
										<?php echo AdminServUI::getLangList(); ?>
									</div>
								<?php endif; ?>

							</div>
						<?php endif; ?>

						<?php if (AdminServEvent::isLoggedIn()): ?>

							<!-- Speed Admin -->
							<?php if (AdminServAdminLevel::hasPermission('speed_admin')): ?>
								<div class="speed-admin">
									<ul>
										<li><a tabindex="-1" class="prev"     href=".">PrevMap</a></li>
										<li><a tabindex="-1" class="restart"  href=".">RestartMap</a></li>
										<li><a tabindex="-1" class="next"     href=".">NextMap</a></li>
										<li><a tabindex="-1" class="endround" href=".">ForceEndRound</a></li>
									</ul>
								</div>
							<?php endif; ?>

							<!-- Switch Server -->
							<?php if (AdminServAdminLevel::hasPermission('switch_server')): ?>
								<div class="switch-server">
									<select tabindex="1" id="switchServerList" name="switchServerList">
										<?php echo AdminServUI::getServerList(); ?>
									</select>
								</div>
							<?php endif; ?>

						<?php endif; ?>

						<!-- Powiadomienia -->
						<div id="error"<?php if (!isset($_SESSION['error'])): echo ' hidden="hidden"'; endif; ?>>
							<?php if (isset($_SESSION['error']) && $_SESSION['error'] != null): echo $_SESSION['error']; unset($_SESSION['error']); endif; ?>
						</div>
						<div id="info"<?php if (!isset($_SESSION['info'])): echo ' hidden="hidden"'; endif; ?>>
							<?php if (isset($_SESSION['info']) && $_SESSION['info'] != null): echo $_SESSION['info']; unset($_SESSION['info']); endif; ?>
						</div>

					</div><!-- #header-inner -->
					<div id="header-color-line"></div>
				</header>

				<!-- ===== NAWIGACJA ===== -->
				<?php if (AdminServEvent::isLoggedIn()): ?>
					<nav class="horizontal-nav">
						<div id="nav-inner" class="menu-principal">
							<ul class="menu-left">
								<li class="accessgeneral">
									<a tabindex="2" accesskey="1" class="button light<?php if (USER_PAGE == 'index'): echo ' active'; endif; ?>" href="./">
										<?php echo Utils::t('General'); ?>
									</a>
								</li>
								<?php if (AdminServAdminLevel::hasAccess('results')): ?>
									<li class="accessresults"><a tabindex="3" class="button light<?php if (USER_PAGE == 'results'): echo ' active'; endif; ?>" href="?p=results"><?php echo Utils::t('Results'); ?></a></li>
								<?php endif; ?>
								<?php if (AdminServAdminLevel::hasAccess('server_options')): ?>
									<li><a tabindex="4" class="button light<?php if (USER_PAGE == 'srvopts'): echo ' active'; endif; ?>" href="?p=srvopts"><?php echo Utils::t('Server options'); ?></a></li>
								<?php endif; ?>
								<?php if (AdminServAdminLevel::hasAccess('game_infos')): ?>
									<li><a tabindex="5" class="button light<?php if (USER_PAGE == 'gameinfos'): echo ' active'; endif; ?>" href="?p=gameinfos"><?php echo Utils::t('Game infos'); ?></a></li>
								<?php endif; ?>
								<?php if (AdminServAdminLevel::hasAccess('chat')): ?>
									<li><a tabindex="5" class="button light<?php if (USER_PAGE == 'chat'): echo ' active'; endif; ?>" href="?p=chat"><?php echo Utils::t('Chat'); ?></a></li>
								<?php endif; ?>
								<?php if (AdminServAdminLevel::hasAccess('maps_list')): ?>
									<li><a tabindex="6" class="button light<?php if (AdminServUI::isPageType('maps')): echo ' active'; endif; ?>" href="?p=maps-list"><?php echo Utils::t('Maps'); ?></a></li>
								<?php endif; ?>
							</ul>
							<ul class="menu-right">
								<?php if (AdminServAdminLevel::hasAccess('link_access_server')): ?>
									<?php if (defined('IS_RELAY') && IS_RELAY): ?>
										<li class="accesslink"><a tabindex="7" class="button light" href="<?php echo AdminServ::getProtocolLink('#spectate='.SERVER_LOGIN); ?>"><?php echo Utils::t('Access relay'); ?></a></li>
									<?php else: ?>
										<li class="accesslink"><a tabindex="8" class="button light" href="<?php echo AdminServ::getProtocolLink('#join='.SERVER_LOGIN); ?>"><?php echo Utils::t('Access server'); ?></a></li>
									<?php endif; ?>
								<?php endif; ?>
								<?php if (AdminServPlugin::hasPlugin() && AdminServAdminLevel::hasAccess('plugins_list')): ?>
									<li><a tabindex="9" class="button light<?php if (USER_PAGE == 'plugins-list' || USER_PLUGIN): echo ' active'; endif; ?>" href="?p=plugins-list"><?php echo Utils::t('Plugins'); ?></a></li>
								<?php endif; ?>
								<?php if (AdminServAdminLevel::hasAccess('guest_ban')): ?>
									<li><a tabindex="10" class="button light<?php if (USER_PAGE == 'guestban'): echo ' active'; endif; ?>" href="?p=guestban"><?php echo Utils::t('Guest-Ban'); ?></a></li>
								<?php endif; ?>
								<li><a tabindex="11" class="button light" href="?logout"><?php echo Utils::t('Disconnect'); ?></a></li>
							</ul>
						</div>
					</nav>

				<?php elseif (AdminServUI::isPageType('config')): ?>
					<nav class="horizontal-nav">
						<div id="nav-inner" class="menu-principal">
							<ul class="menu-left">
								<?php if (OnlineConfig::ADD_ONLY !== true): ?>
									<li><a class="button light<?php if (USER_PAGE == 'config-servers'): echo ' active'; endif; ?>" href="?p=config-servers"><?php echo Utils::t('Servers'); ?></a></li>
								<?php endif; ?>
								<li><a class="button light<?php if (USER_PAGE == 'config-addserver'): echo ' active'; endif; ?>" href="?p=config-addserver<?php if (defined('IS_SERVER_EDITION')): echo '&id='.$args['id']; endif; ?>"><?php echo (defined('IS_SERVER_EDITION')) ? Utils::t('Edit server') : Utils::t('Add server'); ?></a></li>
								<?php $hasServer = AdminServServerConfig::hasServer(); ?>
								<?php if (OnlineConfig::ADD_ONLY !== true && $hasServer): ?>
									<li><a class="button light<?php if (USER_PAGE == 'config-serversorder'): echo ' active'; endif; ?>" href="?p=config-serversorder"><?php echo Utils::t('Servers order'); ?></a></li>
								<?php endif; ?>
								<?php if (OnlineConfig::ADMINLEVEL): ?>
									<li><a class="button light<?php if (USER_PAGE == 'config-adminlevel'): echo ' active'; endif; ?>" href="?p=config-adminlevel"><?php echo Utils::t('Admin levels'); ?></a></li>
									<li><a class="button light<?php if (USER_PAGE == 'config-addlevel'): echo ' active'; endif; ?>" href="?p=config-addlevel<?php if (defined('IS_LEVEL_EDITION')): echo '&id='.$args['id']; endif; ?>"><?php echo (defined('IS_LEVEL_EDITION')) ? Utils::t('Edit level') : Utils::t('Add level'); ?></a></li>
									<li><a class="button light<?php if (USER_PAGE == 'config-levelsorder'): echo ' active'; endif; ?>" href="?p=config-levelsorder"><?php echo Utils::t('Levels order'); ?></a></li>
								<?php endif; ?>
							</ul>
							<ul class="menu-right">
								<?php if (OnlineConfig::PASSWORD != null): ?>
									<li><a class="button light<?php if (USER_PAGE == 'config-password'): echo ' active'; endif; ?>" href="?p=config-password"><?php echo Utils::t('Change password'); ?></a></li>
								<?php endif; ?>
								<?php if ($hasServer): ?>
									<li><a class="button light" href="./?logout"><?php echo Utils::t('Back'); ?></a></li>
								<?php endif; ?>
							</ul>
						</div>
					</nav>

				<?php elseif (!isset($_SESSION['adminserv']['check_password']) && !isset($_SESSION['adminserv']['get_password'])): ?>
					<nav id="connection">
						<div id="connection-inner">
							<form method="post" action=".">
								<div class="connection-label">
									<label for="as_server"><?php echo Utils::t('Server'); ?></label>
									<select tabindex="1" name="as_server" id="as_server">
										<?php echo AdminServUI::getServerList(); ?>
									</select>
									<label for="as_password"><?php echo Utils::t('Password'); ?></label>
									<input tabindex="2" class="text" type="password" name="as_password" id="as_password" value="" placeholder="••••••••" />
									<label for="as_adminlevel"><?php echo Utils::t('Admin level'); ?></label>
									<select tabindex="3" name="as_adminlevel" id="as_adminlevel" data-error="<?php echo Utils::t('No server admin levels configured.'); ?>"></select>
								</div>
								<div class="connection-login">
									<input tabindex="4" class="button dark" type="submit" name="as_login" id="as_login" value="<?php echo Utils::t('Connection'); ?>" />
								</div>
							</form>
						</div>
					</nav>
				<?php endif; ?>

				<!-- ===== CONTENT ===== -->
				<div id="content">
					<div id="content-inner">
