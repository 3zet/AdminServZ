<?php
	// Includes
	session_start();
	$configPath = '../../'.$_SESSION['adminserv']['path'].'config/';
	require_once $configPath.'adminserv.cfg.php';
	require_once $configPath.'extension.cfg.php';

	// Theme
	$themeColor = (isset($_GET['th'])) ? addslashes((string) $_GET['th']) : AdminServConfig::DEFAULT_THEME;
?>
<?php if($themeColor != null && isset(ExtensionConfig::$THEMES[$themeColor])): ?>
	<?php
		$color1 = ExtensionConfig::$THEMES[$themeColor][0];
		$color2 = ExtensionConfig::$THEMES[$themeColor][1];

		// CSS
		header('Content-type: text/css');
	?>
/* Color */
#title .title-color,
h2,
h3 {
	color: <?php echo $color1; ?>;
}

/* Background color */
#header-color-line,
h1,
.menu .vertical-nav ul li a.active,
.menu .vertical-nav ul li a:hover,
.qq-upload-button-hover,
.qq-upload-drop-area-active,
.qq-progress-bar {
	background-color: <?php echo $color1; ?>;
}
tbody tr.selected,
.options-radio-inline li:hover,
.options-radio-inline li.selected,
.ui-sortable li:hover {
	background-color: <?php echo $color2; ?>;
}

/* Others */
.button.light,
.button.dark {
	-webkit-box-shadow: 0 4px 0 <?php echo $color1; ?>;
	-moz-box-shadow: 0 4px 0 <?php echo $color1; ?>;
	-ms-box-shadow: 0 4px 0 <?php echo $color1; ?>;
	-o-box-shadow: 0 4px 0 <?php echo $color1; ?>;
	box-shadow: 0 4px 0 <?php echo $color1; ?>;
}
fieldset legend {
	-webkit-box-shadow: 0 3px <?php echo $color1; ?>;
	-moz-box-shadow: 0 3px <?php echo $color1; ?>;
	-ms-box-shadow: 0 3px <?php echo $color1; ?>;
	-o-box-shadow: 0 3px <?php echo $color1; ?>;
	box-shadow: 0 3px <?php echo $color1; ?>;
}
.menu .vertical-nav ul li a {
	border-bottom-color: <?php echo $color2; ?>;
}
.options-checkbox {
	border-left-color: <?php echo $color1; ?>;
}
.folders .option-folder-list .arrow-down {
	border-color: <?php echo $color1; ?> transparent transparent;
}
.folders .option-folder-list .arrow-up {
	border-color: transparent transparent <?php echo $color1; ?>;
}
.content p a {
	border-color: <?php echo $color1; ?>;
}
/* DisplayServ widget accent */
.ds-server:hover {
	border-color: <?php echo $color1; ?>55;
}
<?php endif; ?>
